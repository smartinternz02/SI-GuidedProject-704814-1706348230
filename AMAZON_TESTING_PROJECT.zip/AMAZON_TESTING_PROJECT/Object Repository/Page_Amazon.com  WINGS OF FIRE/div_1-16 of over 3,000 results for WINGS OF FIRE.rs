<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_1-16 of over 3,000 results for WINGS OF FIRE</name>
   <tag></tag>
   <elementGuidId>06190798-1ab9-4be6-8de9-b79c67d1d60f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.a-section.a-spacing-small.a-spacing-top-small</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='search']/span[2]/div/h1/div/div/div/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>891be535-76aa-4640-b1a3-f5328fe4b90b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-section a-spacing-small a-spacing-top-small</value>
      <webElementGuid>c36961e2-f074-411e-8d6b-9230a899adea</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                1-16 of over 3,000 results for &quot;WINGS OF FIRE&quot;
            </value>
      <webElementGuid>79752cc5-76d8-41b2-9e83-9fae8fd27875</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;search&quot;)/span[@class=&quot;rush-component&quot;]/div[@class=&quot;s-widget-container s-spacing-small s-widget-container-height-small celwidget slot=UPPER template=RESULT_INFO_BAR widgetId=result-info-bar&quot;]/h1[@class=&quot;a-size-base s-desktop-toolbar a-text-normal&quot;]/div[@class=&quot;s-desktop-width-max sg-row-align-items-center s-wide-grid-style sg-row&quot;]/div[@class=&quot;sg-col-4-of-24 sg-col-3-of-12 sg-col-4-of-16 sg-col s-breadcrumb sg-col-4-of-20&quot;]/div[@class=&quot;sg-col-inner&quot;]/div[@class=&quot;a-section a-spacing-small a-spacing-top-small&quot;]</value>
      <webElementGuid>931407db-bcc3-42fa-9ed5-e670dff920b1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='search']/span[2]/div/h1/div/div/div/div</value>
      <webElementGuid>9afa35f7-32fe-43c6-bfa0-3472375b2b72</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h1/div/div/div/div</value>
      <webElementGuid>b662e756-b651-43f2-80bf-633a9fd138e5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                1-16 of over 3,000 results for &quot;WINGS OF FIRE&quot;
            ' or . = '
                1-16 of over 3,000 results for &quot;WINGS OF FIRE&quot;
            ')]</value>
      <webElementGuid>e6c90421-e603-4fe5-9e4a-b47219fed8c4</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
