<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Added to Cart</name>
   <tag></tag>
   <elementGuidId>c1e59c56-3b07-4bf3-ad04-330109b47de2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.a-section.a-padding-medium.sw-atc-message-section</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='sw-atc-details-single-container']/div[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>bdedd13f-3809-4da9-92f2-c2ca104a87ff</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-section a-padding-medium sw-atc-message-section</value>
      <webElementGuid>c243c8ed-e64f-4495-96c0-6d0fd8135047</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    
        
            

















    
    

    
        
            Added to Cart
        
    


        
        
    
    
        
















    
    
        













    
    
    
    
    
    
</value>
      <webElementGuid>3c24dd04-cc2e-4ffc-bad3-ca4a02991b02</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;sw-atc-details-single-container&quot;)/div[@class=&quot;a-section a-padding-medium sw-atc-message-section&quot;]</value>
      <webElementGuid>82ac056f-7036-4092-af47-c371e87eab1e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='sw-atc-details-single-container']/div[2]</value>
      <webElementGuid>e2f03ee1-f64a-4b45-aa52-9b6772561059</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div/div/div/div[2]</value>
      <webElementGuid>f43245ca-b204-4c1b-9b0b-b40eed33c1b0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
    
        
            

















    
    

    
        
            Added to Cart
        
    


        
        
    
    
        
















    
    
        













    
    
    
    
    
    
' or . = '
    
        
            

















    
    

    
        
            Added to Cart
        
    


        
        
    
    
        
















    
    
        













    
    
    
    
    
    
')]</value>
      <webElementGuid>908c1817-147c-4139-8786-e8f330fc6795</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
